const corporativoDescriptografaTokenRetornaUsuario = require('services/corporativo-descriptografa-token-retorna-usuario.js');

exports.descriptografarTokenRetornarUsuario = (event, context, callback) => {
	corporativoDescriptografaTokenRetornaUsuario.descriptografarTokenRetornarUsuario(event, context, callback);
};
