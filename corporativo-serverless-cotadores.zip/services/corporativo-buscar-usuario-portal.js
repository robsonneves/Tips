const oracledb = require('oracledb-for-lambda');
const dbConfig = require('./dbconfig.js');
const sql = require('./sql.js');
const executeSelect = require('./executeSelect.js');
const httpResponse = require('./httpResponse.js');
const recursos = require('./recurso/recursos.js');
let tipoUsuario;

module.exports.buscarUsuarioPortal = (event, callback) => {

	try {
        tipoUsuario = event.tokenDescriptografado.tipoUsuario;
        oracledb.getConnection(
            {
                user          : dbConfig.user,
                password      : dbConfig.password,
                connectString : dbConfig.connectString
            },
            ( err, connection ) =>
                executeSelect(
                    err,
                    connection,
                    query[ tipoUsuario ](),
                    getParameters(
                            event.tokenDescriptografado.codOrgProd,
                            event.tokenDescriptografado.codCentralCorretor,
                            event.tokenDescriptografado.sub,
                            tipoUsuario)(),
                    process.env.MAX_ROWS,
                    montarResultado,
                    callback)
            );

	} catch (e) {
	    console.log(e);
	}
};

const montarResultado = (err, result) => err ?
    httpResponse.buildInternalServerError() : httpResponse.buildSuccess(montarUsuario(result))

const montarUsuario = (rows) => rows.map( (row) => {
    return usuario[tipoUsuario](row);
} )

const usuario = {
    'C': (row) => recursos.corretor(row),
    'K': (row) => recursos.corretor(row),
    'G': (row) => recursos.grupo(row),
    'F': (row) => recursos.funcionario(row)
};

const query = {
    'C': () => sql.queryCorretor,
    'K': () => sql.queryCorretor,
    'G': () => sql.queryGrupo,
    'F': () => sql.queryFuncionario
};

const getParameters = (idFilial, idCorretor, idUsuarioWeb, tipoUsuario) =>
    tipoUsuario === 'C' || tipoUsuario === 'K' ? () => [idFilial, idCorretor] : [idUsuarioWeb]
