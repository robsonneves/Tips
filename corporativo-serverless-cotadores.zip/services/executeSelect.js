module.exports = (_err, _connection, _query, _parameters = [], _maxRows = 180, response, callback) => {
     if (_err) {
         callback(response(_err, null), null)
         console.log("Erro na conexão com banco de dados", _err);
       return;
     }
     _connection.execute(
         _query, _parameters, { maxRows: _maxRows },

         function(_err, result) {
             if (_err) {
               doRelease(_connection)
               callback(response(_err, null), null)
               console.log("Erro na conexão com banco de dados", _err);
             }

             doRelease(_connection)
             callback(null, response(null, result.rows))
         }
     );
}

const doRelease = (connection) => {
    connection.close((err) => {
        if (err) console.log(err.message)
    });
}