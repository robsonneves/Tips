module.exports.corretor = (row) => {
    return {
        idCotador: row[0],
        nomeUsuario: row[1],
        email: row[2],
        grupoAcesso : row[3],
        perfilAcesso : {
            idPerfilAcesso: row[4],
            dsPerfilAcesso: row[5]
        },
        dddTelefone: row[6],
        telefone: row[7],
        idCorretora: row[8],
        filial : {
            idFilial : row[9],
            nomeFilial : row[10]
        },
        grupoInstitucional: {
            idGrupoInstitucional : row[11],
            nomeGrupo: row[12]
        },
        codSusep : row[13]
    }
};

module.exports.grupo = (row) => {
    return {
        idCotador: row[0],
        nomeUsuario: row[1],
        grupoAcesso : row[2],
        perfilAcesso : {
            idPerfilAcesso: row[3],
            dsPerfilAcesso: row[4]
        },
        idGrupoInstitucional : row[5]
    }
};

module.exports.funcionario = (row) => {
    return {
        idCotador: row[0],
        nomeUsuario: row[1],
        email: row[2],
        grupoAcesso : row[3],
        perfilAcesso : {
            idPerfilAcesso: row[4],
            dsPerfilAcesso: row[5]
        },
    }
};