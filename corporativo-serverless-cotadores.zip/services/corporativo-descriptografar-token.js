/******************************************************************************
 * NAME
 *   node.js
 *
 * DESCRIPTION
 *   Função nodejs para descriptografar o token.
 *
 *****************************************************************************/

const jwt = require('jsonwebtoken');

module.exports.descriptografarToken = (event) => {
    return jwt.verify(event.token, 'a740fb47115bfc7b0725d136d078df79', (erro, decoded) => {
        if(erro){ return JSON.stringify(erro); }else{ return decoded; };
    }); 
}
