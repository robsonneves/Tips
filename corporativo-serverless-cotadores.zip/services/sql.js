module.exports = {
    queryCorretor :
        `SELECT
            c.id_usu_web          As id_usu_web,
            c.nome_corretor       As nome_usuario,
            c.e_mail,
            g.ds_metaname         AS grupo_acesso,
            g.id_perfil_acesso    As perfil_acesso,
            pa.ds_perfil_acesso   as ds_perfil_acesso,
            c.ddd,
            c.no_telefone,
            c.cod_corretor,
            d.cod_org_prod        AS cod_filial,
            d.nome_org_prod       AS nome_filial,
            b.cod_grupo_corr      AS cod_grupo_institucional,
            b.nome_grupo_corr     AS nome_grupo_institucional,
            c.cod_corr_susep_re   AS cod_susep           
        FROM
            vt_grupo_corr_assoc a,
            vt_grupo_corr b,
            vt_corretor c,
            vt_org_prod d,
            tb_grupo_usuario gu,
            tb_grupo g,
            tb_perfil_acesso pa
        WHERE
            a.cod_org_prod =: idFilial
            AND a.cod_corretor =: idCorretor
            AND a.desl_s_n = 'N'
            AND b.cod_empr = a.cod_empr
            AND b.cod_grupo_corr = a.cod_grupo_corr
            AND b.tipo_grupo = 3
            AND c.cod_empr = a.cod_empr
            AND c.cod_org_prod = a.cod_org_prod
            AND c.cod_corretor = a.cod_corretor
            AND d.cod_empr = c.cod_empr
            AND d.cod_org_prod = c.cod_org_prod
            AND gu.id_usu_web = c.id_usu_web
            AND gu.cod_empr = c.cod_empr
            AND gu.id_grupo = g.id_grupo
            and g.id_perfil_acesso = pa.id_perfil_acesso`,

    queryGrupo :
        `SELECT
            gc.id_usuario_web,
            gc.nome_grupo_corr    AS nome_grupo_institucional,
            g.ds_metaname         AS grupo_acesso,
            g.id_perfil_acesso    As perfil_acesso,
            pa.ds_perfil_acesso   as ds_perfil_acesso,
            gc.COD_GRUPO_CORR     As cod_grupo_institucional
        FROM
            vt_grupo_corr gc,
            tb_grupo_usuario gu,
            tb_grupo g,
            tb_perfil_acesso pa
        WHERE
            gc.id_usuario_web =: idUsuarioWeb
            AND gc.id_usuario_web = gu.id_usu_web
            AND gc.cod_empr = gu.cod_empr
            AND gu.id_grupo = g.id_grupo
            and g.id_perfil_acesso = pa.id_perfil_acesso`,

    queryFuncionario :
        `SELECT
            gc.id_usuario_web,
            gc.nome_grupo_corr    AS nome_grupo_institucional,
            g.ds_metaname         AS grupo_acesso,
            g.id_perfil_acesso    As perfil_acesso,
            pa.ds_perfil_acesso   as ds_perfil_acesso,
            gc.COD_GRUPO_CORR     As cod_grupo_institucional
        FROM
            vt_grupo_corr gc,
            tb_grupo_usuario gu,
            tb_grupo g,
            tb_perfil_acesso pa
        WHERE
            gc.id_usuario_web =: idUsuarioWeb
            AND gc.id_usuario_web = gu.id_usu_web
            AND gc.cod_empr = gu.cod_empr
            AND gu.id_grupo = g.id_grupo
            and g.id_perfil_acesso = pa.id_perfil_acesso`
};