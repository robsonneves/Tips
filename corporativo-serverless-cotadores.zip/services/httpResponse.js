const MSG_ERRO_INESPERADO = "Erro inesperado, entre em contato com o administrador do sistema e informe o código fornecido.";
const MSG_ARGUMENTO_INVALIDO = "Argumento inválido.";

module.exports.buildInternalServerError = () => {
    return buildResponse(500, errorJsonMessage(MSG_ERRO_INESPERADO));
};

module.exports.buildBadRequestError = () => {
    return buildResponse(400, errorJsonMessage(MSG_ARGUMENTO_INVALIDO));
};

module.exports.buildSuccess = (result) => {
    return buildResponse(200, result);
};

function buildResponse(statusCode, message) {
	var response = {
        "statusCode": statusCode,
        "headers": {
            "Content-Type": "application/json",
			"Access-Control-Allow-Origin" : "*"
        },
        "body": JSON.stringify(message),
        "isBase64Encoded": false
    };
	return response;
}

function errorJsonMessage(message) {
	var json = {
		message : message
	};
	return json;
}