/******************************************************************************
 * NAME
 *   node.js
 *
 * DESCRIPTION
 *   Função nodejs para descriptografar o token e retornar o usuario.
 *
 *****************************************************************************/

const descriptografarToken = require('./corporativo-descriptografar-token');
const buscarUsuario        = require('./corporativo-buscar-usuario-portal');

module.exports.descriptografarTokenRetornarUsuario = (event, context, callback) => {

    if(event.hasOwnProperty('token')){ 
        event.token = tratarToken(event.token);
    }else{ 
        event.token = tratarToken(event.headers.Authorization);
    }; 

    let tokenDescriptografado = descriptografarToken.descriptografarToken(event);
    event.tokenDescriptografado = tokenDescriptografado;
    buscarUsuario.buscarUsuarioPortal(event, callback);

}

function tratarToken(token){
    token = token.replace(' ', '');
    token = token.replace('Bearer', '');
    return token;
}

